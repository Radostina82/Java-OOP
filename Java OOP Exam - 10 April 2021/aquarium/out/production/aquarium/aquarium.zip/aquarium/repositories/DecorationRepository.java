package aquarium.repositories;

import aquarium.entities.decorations.Decoration;

public class DecorationRepository implements Repository {
    @Override
    public void add(Decoration decoration) {

    }

    @Override
    public boolean remove(Decoration decoration) {
        return false;
    }

    @Override
    public Decoration findByType(String type) {
        return null;
    }
}
