package restaurant.entities.drinks;

import restaurant.entities.drinks.interfaces.Beverages;

public abstract class BaseBeverage implements Beverages {
    private StringBuilder name;
    private int counter;
    private double price;
    private StringBuilder brand;

    protected BaseBeverage(StringBuilder name, int counter, double price, StringBuilder brand) {
        this.setName(name);
        this.setCounter(counter);
        this.setPrice(price);
        this.setBrand(brand);
    }

    private void setName(StringBuilder name) {
        this.name = name;
    }

    private void setCounter(int counter) {
        this.counter = counter;
    }

    private void setPrice(double price) {
        this.price = price;
    }

    private void setBrand(StringBuilder brand) {
        this.brand = brand;
    }

    @Override
    public String getName() {
        return null;
    }

    @Override
    public int getCounter() {
        return 0;
    }

    @Override
    public double getPrice() {
        return 0;
    }

    @Override
    public String getBrand() {
        return null;
    }
}
