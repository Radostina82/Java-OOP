package restaurant.entities.drinks;

public class Fresh extends BaseBeverage{
    private static final double freshPrice = 3.50;
    protected Fresh(StringBuilder name, int counter, StringBuilder brand) {
        super(name, counter, freshPrice, brand);
    }
}
