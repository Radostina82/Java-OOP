package restaurant.entities.drinks;

public class Smoothie extends BaseBeverage{
    private static final double smoothiePrice = 4.50;
    protected Smoothie(StringBuilder name, int counter, StringBuilder brand) {
        super(name, counter, smoothiePrice, brand);
    }
}
