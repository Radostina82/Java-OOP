package restaurant.common.enums;

public enum TableType {
    Indoors,
    InGarden
}
