package viceCity.common;

public enum  Command {
    AddPlayer,
    AddGun,
    AddGunToPlayer,
    Fight,
    Exit,
}
