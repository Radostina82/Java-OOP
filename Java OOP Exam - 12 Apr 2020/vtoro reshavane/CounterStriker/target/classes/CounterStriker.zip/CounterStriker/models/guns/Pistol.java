package CounterStriker.models.guns;

public class Pistol extends GunImpl{
    protected Pistol(String name, int bulletsCount) {
        super(name, bulletsCount);
    }
}
